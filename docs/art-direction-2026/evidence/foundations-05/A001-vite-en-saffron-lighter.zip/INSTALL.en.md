# State Relay / A001 — Installation

State Relay (A001@0.1.0-prototype) is a React/TypeScript button with ready, pending, success and error states. The included example copies text; you can connect your own async action. Selected settings: Vite React + TypeScript; locale=en; motion=off; duration=0ms; accent=#EBD183. Source license: MIT (LICENSE.txt).

Copy the complete bundle into src/recipes/state-relay/ without changing its structure. Start with SelectedExample.tsx: it imports AfterlightExample.tsx and AfterlightExample.module.css. Shared useStateRelay and createStateRelay are in src/. The component inherits your project's font and uses its existing React, TypeScript and CSS Modules. It adds no runtime packages, images, remote scripts or fonts. Do not update dependencies to latest just to install this component.

Import SelectedExample into your Vite route or Next.js App Router page. The component and hook already use 'use client'; the entire page does not need that directive. Browser APIs run only when the button is activated. SSR and the first hydration both start in idle.

```tsx
import SelectedExample from './recipes/state-relay/SelectedExample';
export default function Screen() { return <SelectedExample />; }
```

To run your own action, replace the controller.run callback in AfterlightExample.tsx. Its Promise must determine success or error. Start the action immediately; do not add artificial pending time, a minimum delay or fabricated progress. For fetch, check response.ok and forward AbortSignal when supported.

Keep the latest-ticket check, cancel/cleanup on reset and unmount, and a separate controller and radio-group name for each instance. While pending, prevent duplicate activation without moving focus or changing the button hit area. Keep the native button, text status and aria-live announcements. Errors stay visible until another action or reset. System reduced motion and motion=off disable transitions and rotation while preserving state and messages.

The clipboard example requires HTTPS or localhost and browser permission. Handle a missing Clipboard API and permission denial. Clipboard writes cannot use AbortSignal: reset ignores a late result, but a write already in progress may still finish. The Error · simulation option is an explicitly local example; it makes no server request.

Run the controller tests with Node 24+: node --test controller.test.mjs from the bundle root. Also check copy success and permission denial, error simulation, reset, two instances, stale results, unmount/Strict Mode, keyboard use, EN/RU/VI, 320px/200% zoom, motion=off and a live reduced-motion change. Run typecheck/build in your Next.js or Vite project; included source does not prove compatibility with every version.

This bundle contains the current Afterlight example. Its visual design is awaiting approval; it is not a completed commercial release.
