# State Relay / A001 — Подключение

State Relay (A001@0.1.0-prototype) — кнопка для React/TypeScript с состояниями готовности, выполнения, успеха и ошибки. В примере она копирует текст; вместо этого можно подключить свою асинхронную операцию. Выбранные параметры: Vite React + TypeScript; locale=en; motion=off; duration=0ms; accent=#EBD183. Лицензия исходников — MIT (LICENSE.txt).

Скопируйте комплект целиком в src/recipes/state-relay/, сохранив структуру. Начните с SelectedExample.tsx: он импортирует AfterlightExample.tsx и AfterlightExample.module.css. Общие useStateRelay и createStateRelay находятся в src/. Компонент наследует шрифт проекта и использует существующие React, TypeScript и CSS Modules. Новые runtime-пакеты, изображения, удалённые скрипты и шрифты не нужны. Не обновляйте зависимости до latest ради подключения компонента.

Импортируйте SelectedExample в маршрут Vite или страницу Next.js App Router. Компонент и hook уже содержат 'use client'; добавлять директиву ко всей странице не требуется. Browser API вызывается только по нажатию. SSR и первая гидратация начинаются в idle.

```tsx
import SelectedExample from './recipes/state-relay/SelectedExample';
export default function Screen() { return <SelectedExample />; }
```

Чтобы подключить свою операцию, замените callback controller.run в AfterlightExample.tsx. Его Promise должен определять success или error. Запускайте операцию сразу, без искусственного pending, минимальной задержки и выдуманного прогресса. Для fetch проверяйте response.ok и передавайте AbortSignal, если API поддерживает отмену.

Сохраните проверку latest-ticket, cancel/cleanup при reset и unmount, отдельный контроллер и имя radio-группы для каждого экземпляра. Во время pending блокируйте повторный запуск, сохраняя фокус и область нажатия кнопки. Оставьте нативный button, текстовые сообщения и aria-live. Ошибка остаётся видимой до следующего действия или сброса. Системный reduced motion и motion=off отключают переходы и вращение без потери состояния и сообщений.

Для копирования нужны HTTPS или localhost и разрешение браузера. Обрабатывайте отсутствие Clipboard API и отказ в доступе. Clipboard не поддерживает AbortSignal: reset игнорирует поздний результат, но уже начатая запись может завершиться. Сценарий «Ошибка · симуляция» явно локальный и не отправляет запрос на сервер.

Запустите контроллерные тесты в Node 24+: node --test controller.test.mjs из корня комплекта. Отдельно проверьте успешное копирование и отказ разрешения, симуляцию ошибки, reset, два экземпляра, поздний результат, unmount/Strict Mode, клавиатуру, EN/RU/VI, 320px/200% zoom, motion=off и динамический reduced motion. Выполните typecheck/build в своём Next.js или Vite проекте: наличие исходников не подтверждает совместимость со всеми версиями.

Комплект содержит текущий пример Afterlight. Его оформление ожидает оценки; это не завершённый коммерческий релиз.
