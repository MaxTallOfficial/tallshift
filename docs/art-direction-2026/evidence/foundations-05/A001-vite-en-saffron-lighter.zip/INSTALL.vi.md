# State Relay / A001 — Tích hợp

State Relay (A001@0.1.0-prototype) là nút React/TypeScript với các trạng thái sẵn sàng, đang xử lý, thành công và lỗi. Ví dụ đi kèm sao chép văn bản; bạn có thể thay bằng thao tác bất đồng bộ của mình. Cấu hình đã chọn: Vite React + TypeScript; locale=en; motion=off; duration=0ms; accent=#EBD183. Giấy phép mã nguồn: MIT (LICENSE.txt).

Sao chép toàn bộ bộ mã vào src/recipes/state-relay/ và giữ nguyên cấu trúc. Bắt đầu từ SelectedExample.tsx: tệp này nhập AfterlightExample.tsx và AfterlightExample.module.css. useStateRelay và createStateRelay dùng chung nằm trong src/. Component dùng phông chữ, React, TypeScript và CSS Modules sẵn có của dự án. Không cần thêm gói runtime, hình ảnh, script từ xa hoặc phông chữ. Không nâng cấp dependency lên latest chỉ để cài component này.

Nhập SelectedExample vào route Vite hoặc trang Next.js App Router. Component và hook đã có 'use client'; không cần thêm chỉ thị này cho toàn bộ trang. Browser API chỉ được gọi khi nhấn nút. SSR và lần hydration đầu tiên đều bắt đầu ở idle.

```tsx
import SelectedExample from './recipes/state-relay/SelectedExample';
export default function Screen() { return <SelectedExample />; }
```

Để chạy thao tác của bạn, thay callback controller.run trong AfterlightExample.tsx. Promise của callback phải quyết định success hoặc error. Chạy thao tác ngay, không tạo thời gian pending giả, độ trễ tối thiểu hoặc tiến trình không có thật. Với fetch, kiểm tra response.ok và truyền AbortSignal nếu API hỗ trợ hủy.

Giữ kiểm tra latest-ticket, cancel/cleanup khi reset và unmount, cùng controller và tên nhóm radio riêng cho từng component. Khi pending, chặn thao tác lặp nhưng giữ focus và vùng nhấn của nút. Giữ button gốc, thông báo bằng văn bản và aria-live. Lỗi tiếp tục hiển thị cho đến thao tác tiếp theo hoặc reset. Thiết lập reduced motion của hệ thống và motion=off tắt chuyển động nhưng vẫn giữ trạng thái và thông báo.

Ví dụ sao chép cần HTTPS hoặc localhost và quyền của trình duyệt. Xử lý trường hợp không có Clipboard API hoặc người dùng từ chối quyền. Clipboard không hỗ trợ AbortSignal: reset bỏ qua kết quả đến muộn nhưng thao tác ghi đã bắt đầu vẫn có thể hoàn tất. Tùy chọn «Lỗi · mô phỏng» chỉ là ví dụ cục bộ, không gửi yêu cầu đến máy chủ.

Chạy kiểm thử controller bằng Node 24+: node --test controller.test.mjs từ thư mục gốc của bộ mã. Kiểm tra thêm sao chép thành công và từ chối quyền, mô phỏng lỗi, reset, hai component, kết quả đến muộn, unmount/Strict Mode, bàn phím, EN/RU/VI, 320px/zoom 200%, motion=off và thay đổi reduced motion khi đang mở trang. Chạy typecheck/build trong dự án Next.js hoặc Vite; mã nguồn đi kèm không đảm bảo tương thích với mọi phiên bản.

Bộ mã chứa ví dụ Afterlight hiện tại. Thiết kế vẫn đang chờ đánh giá; đây chưa phải bản phát hành thương mại hoàn chỉnh.
