'use client';

import { AfterlightExample } from './AfterlightExample';

const selectedConfig = {
  "locale": "en",
  "motion": "off",
  "accent": "#EBD183",
  "duration": 0
} as const;

export default function SelectedExample() {
  return <AfterlightExample {...selectedConfig} />;
}
