# State Relay / A001@0.1.0-prototype

Original local recipe, MIT (LICENSE.txt). Target: Vite React/TS. Locale: ru. Motion: subtle; duration: 120ms; accent: #254EDB.

Installation: INSTALL.en.md. Integration and limitations: INTEGRATE.en.md. Selected entry: SelectedExample.tsx. All source and helpers are included. No added runtime dependency; the host supplies React 19.3.1; other versions have not been separately tested.

Only the real host operation determines success. Clipboard requires HTTPS/localhost and browser permission. The Error scenario is a clearly labeled local simulation without a backend. Off/reduce retains data, focus and status messages. This is not a published commercial release; actual verification belongs in the prototype report.

Controller tests: Node 24+, node --test controller.test.mjs. Browser and target-project verification are separate.
