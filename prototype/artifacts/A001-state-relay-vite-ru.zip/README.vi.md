# State Relay / A001@0.1.0-prototype

Mẫu mã nguồn gốc dùng cục bộ, theo giấy phép MIT (LICENSE.txt). Nền tảng: Vite React/TS. Ngôn ngữ: ru. Chuyển động: subtle; thời lượng: 120ms; màu nhấn: #254EDB.

Cài đặt: INSTALL.vi.md. Tích hợp và giới hạn: INTEGRATE.vi.md. Điểm vào theo cấu hình đã chọn: SelectedExample.tsx. Gói đã có đầy đủ mã nguồn và các hàm hỗ trợ. Không thêm phụ thuộc runtime; dự án cung cấp React 19.3.1. Các phiên bản khác chưa được kiểm tra riêng.

Chỉ báo thành công khi thao tác thật của ứng dụng hoàn tất thành công. Sao chép cần HTTPS/localhost và quyền của trình duyệt. Kịch bản lỗi được ghi rõ là mô phỏng cục bộ, không có backend. Off/reduce giữ nguyên dữ liệu, tiêu điểm bàn phím và thông báo. Đây là bản mẫu cục bộ, chưa phải bản phát hành thương mại; các kiểm tra đã thực hiện được ghi trong báo cáo bản mẫu.

Kiểm thử controller: Node 24+, node --test controller.test.mjs. Kiểm tra trên trình duyệt và dự án đích được thực hiện riêng.
