'use client';

import { StateRelayDemo } from './Example';

const selectedConfig = {
  "locale": "ru",
  "motion": "subtle",
  "accent": "#254EDB",
  "duration": 120
} as const;

export default function SelectedExample() {
  return <StateRelayDemo {...selectedConfig} />;
}
